package java0426_class.part06;
/*
 * [출력결과]
 * 기업은행 42523-52325 100000
 * 하나은행 52253-22623 153000
 * 신한은행 16239-95235 256000
 * 총납입액:509000
 */
public class Java078_class {

	public static void main(String[] args) {
		//구현
		CreditCard[] cr=new CreditCard[3];
		cr[0]= new CreditCard("기업은행" "42523-52325" 100000);
		cr[1]= new CreditCard("하나은행" "52253-22623"153000);
		cr[2]= new CreditCard("신한은행" "16239-95235" 256000);
		int sum =process(is,search);
	}//end main()

}//end class
